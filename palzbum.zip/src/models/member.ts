export class Member{
    id:number; 
    group_member_id:number; 
    name:string; 
    surname:string; 
    phone:string; 
    email:string;     
    address:string; 
    dob:string; 
    gender:string; 
    quote:string; 
    profile_img:string; 
    about:string; 
    interest:string 
}