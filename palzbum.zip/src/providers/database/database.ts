import { Injectable } from '@angular/core';
import { Platform, ToastController } from 'ionic-angular';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { SQLitePorter } from '@ionic-native/sqlite-porter';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/Rx';
import { Storage } from '@ionic/storage';
import { RootUrl, AppVersion } from '../../pages';
import { Api } from '../../providers/api/api';
import { HttpClient } from '@angular/common/http';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';

@Injectable()
export class DatabaseProvider {
  groupId = 0;
  database: SQLiteObject;
  private databaseReady: BehaviorSubject<boolean>;

  palz: { group_member_id: number, app_version: string, exclude_group_member_id:string } = {
    group_member_id: 0,
    app_version: AppVersion,
    exclude_group_member_id: '',
  };

  album: { group_id: number, app_version: string, exclude_album_id:string } = {
    group_id: 0,
    app_version: AppVersion,
    exclude_album_id: '',
  };

  photo: { group_member_id: string, app_version: string, exclude_photo_id:string } = {
    group_member_id: '',
    app_version: AppVersion,
    exclude_photo_id: '',
  };
 
  constructor(public sqlitePorter: SQLitePorter, private storage: Storage, public toastCtrl: ToastController,
    private sqlite: SQLite, private platform: Platform, private http: Http, public httpClient: HttpClient,
    public api: Api, private transfer: FileTransfer, private file: File) {
    
    this.setGroupId();

    this.databaseReady = new BehaviorSubject(false);
    this.platform.ready().then(() => {
      this.sqlite.create({
        name: 'palzbum.db',
        location: 'default'
      })
        .then((db: SQLiteObject) => {
          this.database = db;
          this.storage.get('database_filled').then(val => {
            if (val) {
              this.databaseReady.next(true);
            } else {
              this.fillDatabase();
            }
          });

        });
    });

    
  }
 
  async setGroupId(){
    await this.storage.get('current_group_id').then(val => {
      if (val) {
        this.groupId = val;
      }
    });
  }

  fillDatabase() {
    this.http.get('assets/palzbum.sql')
      .map(res => res.text())
      .subscribe(sql => {
        this.sqlitePorter.importSqlToDb(this.database, sql)
          .then(data => {
            this.databaseReady.next(true);
            this.storage.set('database_filled', true);
          })
          .catch(e => console.error(e));
      });
  }
 
  async setCurrentGroupId(id){
    this.groupId = id;
    await this.storage.set('current_group_id', id);
    console.log('current_group_id set to ' + id);
  }

  async setCurrentGroupMemberId(id){
    await this.storage.set('current_group_member_id', id);
    console.log('current_group_member_id set to ' + id);
  }

  async setCurrentUserId(id){
    this.groupId = id;
    await this.storage.set('user_id', id);
    console.log('current_user_id set to ' + id);
  }

  async setCurrentUserPassword(id){
    await this.storage.set('user_password', id);
    console.log('current_user_password set to ' + id);
  }

  async setCurrentUserEmail(id){
    await this.storage.set('user_email', id);
    console.log('current_user_email set to ' + id);
  }

  addDeveloper(name, skill, years) {
    let data = [name, skill, years]
    return this.database.executeSql("INSERT INTO developer (name, skill, yearsOfExperience) VALUES (?, ?, ?)", data).then(data => {
      return data;
    }, err => {
      console.log('Error: ', err);
      return err;
    });
  }

  addGroup(group_id, name, group_member_id, description, user_id, user_password, user_email) {
    let data = [group_id, name, group_member_id, description, user_id, user_password, user_email]
    return this.database.executeSql("INSERT INTO my_group (group_id, name, group_member_id, description, user_id, user_password, user_email) VALUES (?, ?, ?, ?, ?, ?, ?)", data).then(data => {
      console.log('group inserted');
      return data;
    }, err => {
      console.log('Error: ', err);
      return err;
    });
  }

  addPeople(member) {
    let data = [member.id, member.group_member_id, member.group_id, member.surname, member.firstname,member.othername, member.phone, 
      member.email, member.address, member.dob, member.gender, member.quote, member.profile_img, member.about, member.interest, member.show_dob ];
    return this.database.executeSql("INSERT INTO people (profile_id, group_member_id, group_id, surname, firstname, othername, phone, email, address, dob, gender, quote, profile_img, about, interest, show_dob) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", data).then(data => {
      console.log('insert of ' + member.group_member_id + ':');
      return 1;      
    }, err => {
      console.log('Error:', err);
      return 0;
    });
  }
 
  addAlbum(member) {
    console.log('inserting to album ' + member.name + ':');
    let data = [member.id, member.group_id, member.group_member_id, member.name, member.is_deleted];
    return this.database.executeSql("INSERT INTO album (album_id, group_id, group_member_id, name, isdeleted) VALUES (?, ?, ?, ?, ?)", data).then(data => {
      console.log('inserted to album ' + member.name + ':');
      return 1;      
    }, err => {
      console.log('Error:', err);
      return 0;
    });
  }

  async addPhoto(member, groupId) {
    console.log('inserting to photo ' + member.name + ':');
    let data = [member.id, member.group_member_id, member.name, member.album_id, groupId, member.description];
    await this.database.executeSql("INSERT INTO photo ( photo_id, group_member_id, name, album_id, group_id, description) VALUES (?, ?, ?, ?, ?, ?)", data).then(data => {
      console.log('inserted to photo ' + member.name + ':');
      return 1;      
    }, err => {
      console.log('Error:', err);
      return 0;
    });
  }
 
  async getMembers() {
    //await this.setGroupId();
    let groupId = this.groupId;
    let profilePic = "";

    return this.database.executeSql("SELECT id, group_member_id, surname, firstname, phone, gender, profile_img, isdownloaded FROM people WHERE group_id = ? ORDER BY firstname ASC", [groupId]).then((data) => {
      let developers = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {

          if(data.rows.item(i).profile_img != '' && data.rows.item(i).isdownloaded == 1){
            profilePic = this.file.dataDirectory + data.rows.item(i).profile_img;
          }else{
            profilePic = this.getAvatar(data.rows.item(i).gender);
          }

          developers.push({ group_member_id:data.rows.item(i).group_member_id, name: data.rows.item(i).firstname + " " + data.rows.item(i).surname, phone: data.rows.item(i).phone, profile_img: profilePic });
        }
      }
      return developers;
    }, err => {
      console.log('Error: ', err);
      return [];
    });
  }

  getAllMembers() {
    //await this.setGroupId();
    let groupId = this.groupId;
    return this.database.executeSql("SELECT * FROM people WHERE group_id = ? ORDER BY firstname ASC", [groupId]).then((data) => {
      let members = [];
      if (data.rows.length > 0) {

        for (var i = 0; i < data.rows.length; i++) {
          let member = {id:0, group_member_id:0, name:"", surname:"", phone:"", email:"", address:"", dob:"", gender:"", quote:"", profile_img:"", about:"", interest:"" };
          member.id = data.rows.item(i).id;
          member.group_member_id = data.rows.item(i).group_member_id;
          member.name = data.rows.item(i).firstname + " " + data.rows.item(i).othername + " " + data.rows.item(i).surname;
          member.surname = data.rows.item(i).surname;
          member.phone = data.rows.item(i).phone;
          member.email = data.rows.item(i).email;
          member.address = data.rows.item(i).address;
  
          
          if(data.rows.item(i).dob){
            member.dob = data.rows.item(i).dob;
          }else{
            member.dob = 'Not Set';
          }
  
          member.gender = this.getGenderName(data.rows.item(i).gender);
  
          member.quote = data.rows.item(i).quote;
          member.interest = data.rows.item(i).interest;
  
          if(data.rows.item(i).profile_img !='' && data.rows.item(i).isdownloaded == 1){
            member.profile_img = this.file.dataDirectory + data.rows.item(i).profile_img;
          }else{
            member.profile_img = this.getAvatar(data.rows.item(i).gender);
          }
          
          member.about = data.rows.item(i).about;

          members.push(member);
        }
      }
      return members;
    }, err => {
      console.log('Error: ', err);
      return [];
    });
  }

  getAllDemoMembers() {
    let profilePic = "";

    return this.database.executeSql("SELECT id, group_member_id, surname, firstname, phone, gender, profile_img, isdownloaded FROM dummy_people WHERE group_id = ? ORDER BY firstname ASC", [1]).then((data) => {
      let developers = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {

          if(data.rows.item(i).profile_img !='' && data.rows.item(i).isdownloaded == 1){
            profilePic = "assets/img/members/" + data.rows.item(i).profile_img;
          }else{
            profilePic = this.getAvatar(data.rows.item(i).gender);
          }

          developers.push({ group_member_id:data.rows.item(i).group_member_id, name: data.rows.item(i).firstname + " " + data.rows.item(i).surname, phone: data.rows.item(i).phone, profile_img: profilePic });
        }
      }
      return developers;
    }, err => {
      console.log('Error: ', err);
      return [];
    });
  }

  getMemberPhotos(group_member_id) {
    return this.database.executeSql("SELECT id, name, description FROM photo WHERE isdownloaded = 1 AND group_member_id = ? ORDER BY id ASC", [group_member_id]).then((data) => {
      let info = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          info.push({ name:this.file.dataDirectory + data.rows.item(i).name, description:data.rows.item(i).description });
        }
      }
      return info;
    }, err => {
      console.log('Error: ', err);
      return [];
    });
  }

  getDemoMemberPhotos(group_member_id) {
    return this.database.executeSql("SELECT id, name, description FROM dummy_photo WHERE isdownloaded = 1 AND group_member_id = ? ORDER BY id ASC", [group_member_id]).then((data) => {
      let info = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          info.push({ name:"assets/img/members/" + data.rows.item(i).name, description:data.rows.item(i).description });
        }
      }
      return info;
    }, err => {
      console.log('Error: ', err);
      return [];
    });
  }

  getMemberData(group_member_id) {
    let member = {id:0, group_member_id:0, name:"", surname:"", phone:"", email:"", address:"", dob:"", gender:"", quote:"", profile_img:"", about:"", interest:"" };
    return this.database.executeSql("SELECT * FROM people WHERE group_member_id = ? ", [group_member_id]).then((data) => {
      
      if (data.rows.length > 0) {
        member.id = data.rows.item(0).id;
        member.group_member_id = data.rows.item(0).group_member_id;
        member.name = data.rows.item(0).firstname + " " + data.rows.item(0).othername + " " + data.rows.item(0).surname;
        member.surname = data.rows.item(0).surname;
        member.phone = data.rows.item(0).phone;
        member.email = data.rows.item(0).email;
        member.address = data.rows.item(0).address;

        
        if(data.rows.item(0).dob){
          member.dob = data.rows.item(0).dob;
        }else{
          member.dob = 'Not Set';
        }

        member.gender = this.getGenderName(data.rows.item(0).gender);

        member.quote = data.rows.item(0).quote;
        member.interest = data.rows.item(0).interest;

        if(data.rows.item(0).profile_img !='' && data.rows.item(0).isdownloaded == 1){
          member.profile_img = this.file.dataDirectory + data.rows.item(0).profile_img;
        }else{
          member.profile_img = this.getAvatar(data.rows.item(0).gender);
        }
        
        member.about = data.rows.item(0).about;
      }
      return member;
    }, err => {
      console.log('Error: ', err);
      return member;
    });
  }

  getMemberDataAvatar(group_member_id) {
    let member = {id:0, group_member_id: group_member_id, name:"", profile_img:""};
    return this.database.executeSql("SELECT id, firstname, surname, othername, gender, profile_img, isdownloaded FROM people WHERE group_member_id = ? ", [group_member_id]).then((data) => {
      
      if (data.rows.length > 0) {
        member.id = data.rows.item(0).id;
        member.name = data.rows.item(0).firstname + " " + data.rows.item(0).othername + " " + data.rows.item(0).surname;
                
        if(data.rows.item(0).profile_img !='' && data.rows.item(0).isdownloaded == 1){
          member.profile_img = this.file.dataDirectory + data.rows.item(0).profile_img;
        }else{
          member.profile_img = this.getAvatar(data.rows.item(0).gender);
        }        
      }
      return member;
    }, err => {
      console.log('Error: ', err);
      return member;
    });
  }

  getDemoMemberData(group_member_id) {
    let member = {id:0, group_member_id:0, name:"", surname:"", phone:"", email:"", address:"", dob:"", gender:"", quote:"", profile_img:"", about:"", interest:"" };
    return this.database.executeSql("SELECT * FROM dummy_people WHERE group_member_id = ? ", [group_member_id]).then((data) => {
      
      if (data.rows.length > 0) {
        member.id = data.rows.item(0).id;
        member.group_member_id = data.rows.item(0).group_member_id;
        member.name = data.rows.item(0).firstname + " " + data.rows.item(0).othername + " " + data.rows.item(0).surname;
        member.surname = data.rows.item(0).surname;
        member.phone = data.rows.item(0).phone;
        member.email = data.rows.item(0).email;
        member.address = data.rows.item(0).address;
        member.dob = data.rows.item(0).dob;

        member.gender = this.getGenderName(data.rows.item(0).gender);

        member.quote = data.rows.item(0).quote;
        member.interest = data.rows.item(0).interest;

        if(data.rows.item(0).profile_img !='' && data.rows.item(0).isdownloaded == 1){
          member.profile_img = "assets/img/members/" + data.rows.item(0).profile_img;
        }else{
          member.profile_img = this.getAvatar(data.rows.item(0).gender);
        }
        
        member.about = data.rows.item(0).about;
      }
      return member;
    }, err => {
      console.log('Error: ', err);
      return [];
    });
  }

  getGroupHighetMemberId(group_id) {
    let info = {status:'failed', number:0};
    
    return this.database.executeSql("SELECT id, group_member_id FROM people WHERE group_id = ? ORDER BY group_member_id DESC LIMIT 1", [group_id]).then((data) => {
      
      info.status = 'success';
      if (data.rows.length > 0) {
        info.number = data.rows.item(0).group_member_id;  
      }else{
        info.number = 0;
      }
      return info;
    }, err => {
      console.log('Error: ', err);
      return info;
    });
      
  }

  getGroupMemberIdAll(group_id) {
    let info = {status:'failed', member_id:[], str_member_id:''};     
    return this.database.executeSql("SELECT id, group_member_id FROM people WHERE group_id = ? ORDER BY group_member_id ASC", [group_id]).then((data) => {
      info.status = 'success';
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          info.member_id.push(data.rows.item(i).group_member_id);
        }
        info.str_member_id = info.member_id.toString();
      }else{}
      return info;
    }, err => {
      console.log('Error: ', err);
      return info;
    });      
  }

  getAlbumAll(group_id) {
    let info = {status:'failed', album:[], albumId:[], str_album_id:''};     
    return this.database.executeSql("SELECT id, album_id, name FROM album WHERE group_id = ? ORDER BY album_id ASC", [group_id]).then((data) => {
      info.status = 'success';
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          info.album.push({id:data.rows.item(i).id, name:data.rows.item(i).name, album_id:data.rows.item(i).album_id});
          info.albumId.push(data.rows.item(i).album_id);
        }
        info.str_album_id = info.albumId.toString();
      }else{}
      return info;
    }, err => {
      console.log('Error: ', err);
      return info;
    });      
  }

  getMyGroups() {
    let info = {status:'failed', group:[]};     
    return this.database.executeSql("SELECT group_id, name, group_member_id, description, user_id, user_password, user_email from my_group WHERE user_id > ? ORDER BY name ASC", [0]).then((data) => {
      info.status = 'success';
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          info.group.push({group_id:data.rows.item(i).group_id, name:data.rows.item(i).name, group_member_id:data.rows.item(i).group_member_id, description:data.rows.item(i).description, user_id:data.rows.item(i).user_id, user_password:data.rows.item(i).user_password, user_email:data.rows.item(i).user_email});
        }
      }else{}
      return info;
    }, err => {
      console.log('Error: ', err);
      return info;
    });      
  }

  getPhotoAll(group_id) {
    let info = {status:'failed', photo:[], photoId:[], str_photo_id:''};     
    return this.database.executeSql("SELECT id, group_member_id, photo_id, name, album_id, group_id, description, isdownloaded FROM photo WHERE group_id = ? ORDER BY photo_id ASC", [group_id]).then((data) => {
      info.status = 'success';
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          info.photo.push({id:data.rows.item(i).id, group_member_id:data.rows.item(i).group_member_id, photo_id:data.rows.item(i).photo_id, name:data.rows.item(i).name, album_id:data.rows.item(i).album_id, group_id:data.rows.item(i).group_id, description:data.rows.item(i).description, isdownloaded:data.rows.item(i).isdownloaded});
          info.photoId.push(data.rows.item(i).photo_id);
        }
        info.str_photo_id = info.photoId.toString();
      }else{}
      return info;
    }, err => {
      console.log('Error: ', err);
      return info;
    });      
  }

  getPhotoByAlbum(album_id) {
    let info = {status:'failed', photo:[], photoId:[], str_photo_id:''}; 
    let img = '';   
    let userimg = ''; 
    return this.database.executeSql("SELECT photo.id, photo.group_member_id, photo.photo_id, photo.name, photo.album_id, photo.group_id, photo.description, photo.isdownloaded, people.firstname, people.surname, people.othername, people.gender, people.profile_img, people.phone, people.email, people.address, people.dob, people.quote, people.interest, people.about, people.isdownloaded as profile_img_isdownloaded FROM photo inner join people WHERE photo.album_id = ? AND photo.isdownloaded = 1 AND people.group_member_id = photo.group_member_id ORDER BY photo.photo_id ASC", [album_id]).then((data) => {
      info.status = 'success';
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) { 
          img = this.resoveImagePath(data.rows.item(i).name);

          //user img
          let member = {id:0, group_member_id:0, name:"", surname:"", phone:"", email:"", address:"", dob:"", gender:"", quote:"", profile_img:"", about:"", interest:"" };
          member.id = data.rows.item(i).id;
          member.group_member_id = data.rows.item(i).group_member_id;
          member.name = data.rows.item(i).firstname + " " + data.rows.item(i).othername + " " + data.rows.item(i).surname;
          member.surname = data.rows.item(i).surname;
          member.phone = data.rows.item(i).phone;
          member.email = data.rows.item(i).email;
          member.address = data.rows.item(i).address;
  
          
          if(data.rows.item(i).dob){
            member.dob = data.rows.item(i).dob;
          }else{
            member.dob = 'Not Set';
          }
  
          member.gender = this.getGenderName(data.rows.item(i).gender);
  
          member.quote = data.rows.item(i).quote;
          member.interest = data.rows.item(i).interest;
  
          if(data.rows.item(i).profile_img !='' && data.rows.item(i).profile_img_isdownloaded == 1){
            member.profile_img = this.file.dataDirectory + data.rows.item(i).profile_img;
          }else{
            member.profile_img = this.getAvatar(data.rows.item(i).gender);
          }
          
          member.about = data.rows.item(i).about;


          info.photo.push({id:data.rows.item(i).id, group_member_id:data.rows.item(i).group_member_id, photo_id:data.rows.item(i).photo_id, name:data.rows.item(i).name, img:img, album_id:data.rows.item(i).album_id, group_id:data.rows.item(i).group_id, description:data.rows.item(i).description, isdownloaded:data.rows.item(i).isdownloaded, username:data.rows.item(i).firstname + ' ' +data.rows.item(i).surname, userimg:userimg, member:member});
          info.photoId.push(data.rows.item(i).photo_id);
        }
        info.str_photo_id = info.photoId.toString();
      }else{}
      return info;
    }, err => {
      console.log('Error: ', err);
      return info;
    });      
  }

  getPhotoByAlbumOthers() {
    let groupId = this.groupId;
    let info = {status:'failed', photo:[], photoId:[], str_photo_id:''}; 
    let img = '';   
    let userimg = '';     
    return this.database.executeSql("SELECT photo.id, photo.group_member_id, photo.photo_id, photo.name, photo.album_id, photo.group_id, photo.description, photo.isdownloaded, people.firstname, people.surname, people.othername, people.gender, people.profile_img, people.phone, people.email, people.address, people.dob, people.quote, people.interest, people.about, people.isdownloaded as profile_img_isdownloaded FROM photo inner join people WHERE photo.group_id = ? AND photo.album_id = 0 AND photo.isdownloaded = 1 AND people.group_member_id = photo.group_member_id ORDER BY photo.photo_id ASC", [groupId]).then((data) => {
      info.status = 'success';
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          img = this.resoveImagePath(data.rows.item(i).name);

          //user img
          let member = {id:0, group_member_id:0, name:"", surname:"", phone:"", email:"", address:"", dob:"", gender:"", quote:"", profile_img:"", about:"", interest:"" };
          member.id = data.rows.item(i).id;
          member.group_member_id = data.rows.item(i).group_member_id;
          member.name = data.rows.item(i).firstname + " " + data.rows.item(i).othername + " " + data.rows.item(i).surname;
          member.surname = data.rows.item(i).surname;
          member.phone = data.rows.item(i).phone;
          member.email = data.rows.item(i).email;
          member.address = data.rows.item(i).address;
  
          
          if(data.rows.item(i).dob){
            member.dob = data.rows.item(i).dob;
          }else{
            member.dob = 'Not Set';
          }
  
          member.gender = this.getGenderName(data.rows.item(i).gender);
  
          member.quote = data.rows.item(i).quote;
          member.interest = data.rows.item(i).interest;
  
          if(data.rows.item(i).profile_img !='' && data.rows.item(i).profile_img_isdownloaded == 1){
            member.profile_img = this.file.dataDirectory + data.rows.item(i).profile_img;
          }else{
            member.profile_img = this.getAvatar(data.rows.item(i).gender);
          }
          
          member.about = data.rows.item(i).about;

          info.photo.push({id:data.rows.item(i).id, group_member_id:data.rows.item(i).group_member_id, photo_id:data.rows.item(i).photo_id, name:data.rows.item(i).name, img:img, album_id:data.rows.item(i).album_id, group_id:data.rows.item(i).group_id, description:data.rows.item(i).description, isdownloaded:data.rows.item(i).isdownloaded, username:data.rows.item(i).firstname + ' ' +data.rows.item(i).surname, userimg:userimg, member:member});
          info.photoId.push(data.rows.item(i).photo_id);
        }
        info.str_photo_id = info.photoId.toString();
      }else{}
      return info;
    }, err => {
      console.log('Error: ', err);
      return info;
    });      
  }

  getDatabaseState() {
    return this.databaseReady.asObservable();
  }
  
  getGenderName(code){
    if(code == 1){
      return 'Male';
    }else if (code == 2){
      return 'Female';
    }else{
      return 'Not set'
    }
  }

  getAvatar(genderCode){
    if(genderCode == 1){
      return "assets/img/avatar_male.jpg";
    }else if (genderCode == 2){
      return "assets/img/avatar_female.jpg";
    }else{
      return "assets/img/avatar.jpg";
    }
  }

  getProfilePhotosNotDownloaded(group_id) {
    return this.database.executeSql("SELECT id, profile_img, isdownloaded FROM people WHERE isdownloaded = 0 AND profile_img != '' AND profile_img IS NOT NULL AND group_id = ? ORDER BY id ASC", [group_id]).then((data) => {
      let info = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          info.push({ name:data.rows.item(i).profile_img, id: data.rows.item(i).id});
        }
      }
      console.log('getProfilePhotosNotDownloaded successfull ');
      return info;
    }, err => {
      console.log('Error getProfilePhotosNotDownloaded: ', err);
      return [];
    });
  }

  getPhotoNotDownloaded(group_id) {
    console.log('getPhotoNotDownloaded');
    return this.database.executeSql("SELECT id, name, isdownloaded FROM photo WHERE isdownloaded = 0 AND group_id = ? ORDER BY id ASC", [group_id]).then((data) => {
      let info = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {         
          info.push({ name:data.rows.item(i).name, id: data.rows.item(i).id});
        }
      }
      console.log('getPhotoNotDownloaded successfull ');
      return info;
    }, err => {
      console.log('Error getPhotoNotDownloaded: ', err);
      return [];
    });
  }

  updateProfileImgIsDownloaded(id) {
    return this.database.executeSql('UPDATE people SET isdownloaded=1 WHERE id=?',[id]).then(data => {
      console.log('updateProfileImgIsDownloaded Updated isdownloaded for: ' + id);
      return data;
    }, err => {
      console.log('updateProfileImgIsDownloaded Error updating isdownloaded: '+id, err);
      return err;
    });
  }

  async updateImageIsDownloaded(id) {
    console.log('updateImageIsDownloaded for: ' + id);
    await this.database.executeSql('UPDATE photo SET isdownloaded=1 WHERE id=?',[id]).then(data => {
      console.log('updateImageIsDownloaded Updated isdownloaded for: ' + id);
      return data;
    }, err => {
      console.log('updateImageIsDownloaded Error updating isdownloaded: '+id, err);
      return err;
    });
  }

  async updateImageIsDownloadedByName(id) {
    console.log('updateImageIsDownloadedByName for: ' + id);
    await this.database.executeSql('UPDATE photo SET isdownloaded=1 WHERE name=?',[id]).then(data => {
      console.log('updateImageIsDownloadedByName Updated isdownloaded for: ' + id);
      return data;
    }, err => {
      console.log('updateImageIsDownloadedByName Error updating isdownloaded: '+id, err);
      return err;
    });
  }

  async setImageDownloadedFromProfile(group_id) {
    console.log('setImageDownloadedFromProfile ');
    await this.database.executeSql("SELECT id, profile_img, isdownloaded FROM people WHERE isdownloaded = 1 AND profile_img != '' AND profile_img IS NOT NULL AND group_id = ? ORDER BY id ASC", [group_id]).then((data) => {
      let info = [];
      if (data.rows.length > 0) {
        for (var i = 0; i < data.rows.length; i++) {
          this.updateImageIsDownloadedByName(data.rows.item(i).profile_img);
        }
      }
      console.log('setImageDownloadedFromProfile successfull ');
      return info;
    }, err => {
      console.log('Error setImageDownloadedFromProfile: ', err);
      return [];
    });
  }

  async downloadProfileImage(group_id){
    let profileImg = [];

    await this.getProfilePhotosNotDownloaded(group_id).then(data => {
      profileImg = data;
    })

    console.log('fetched profile images of group '+group_id+' for download...')
    for(let img of profileImg){
      await this.downloadAndSaveProfilePicture(img.name,img.id);
    }

    console.log('done download images of group '+group_id)
    
  } 
  
  async downloadImage(group_id){   

    console.log('downloadImage');
    let imgs = [];
    console.log('setImageDownloadedFromProfile called');
    await this.setImageDownloadedFromProfile(group_id).then(dataI => {
          
      setTimeout(() => {
        console.log('getPhotoNotDownloaded called');
        this.getPhotoNotDownloaded(group_id).then(data => {
          imgs = data;

            console.log('fetched images of group '+group_id+' for download...')
            for(let img of imgs){
              this.downloadAndSavePicture(img.name,img.id);
            }
        })

      }, 10000);

    })



    console.log('done download all images of group '+group_id)
    
  }

  async downloadAndSaveProfilePicture(name, id) {
    console.log('downloading ... ' + 'id = ' + id + ', name = ' + name );
    const fileTransfer: FileTransferObject = this.transfer.create();
    const url = RootUrl + '/img/uploads/' + name;

    await fileTransfer.download(url, this.file.dataDirectory + name).then((entry) => {
      console.log('download completed: ' + 'id = ' + id + ', name = ' + name );
              this.updateProfileImgIsDownloaded(id);
    }, (error) => {
      console.log('download faild: ' + 'id = ' + id + ', name = ' + name );

      console.log(error);
    });
  }

  async downloadAndSavePicture(name, id) {
    console.log('downloading ... ' + 'id = ' + id + ', name = ' + name );
    const fileTransfer: FileTransferObject = this.transfer.create();
    const url = RootUrl + '/img/uploads/' + name;

    await fileTransfer.download(url, this.file.dataDirectory + name).then((entry) => {
      console.log('download completed: ' + 'id = ' + id + ', name = ' + name );
            this.updateImageIsDownloaded(id);
    }, (error) => {
      console.log('download faild: ' + 'id = ' + id + ', name = ' + name );
      console.log(error);
    });
  }

  //update logic
  async checkUpdateNewPalz(){

    console.log('checkUpdateNewPalz');

    let groupId = this.groupId;

    if(!groupId){
      console.log('Aborting checkUpdateNewPalz, REASON: No group id set');
      return;
    }

    console.log('Preparing for New Palz update for group '+ groupId);
    this.storage.get('current_group_member_id').then(val => {
      if (val) {
        this.palz.group_member_id = val;
        this.getGroupMemberIdAll(groupId).then(data => {
          if(data.status = 'success'){
            console.log('success with update getGroupMemberIdAll'); 
            this.palz.exclude_group_member_id =  data.str_member_id;
            console.log(this.palz.group_member_id + ' for group '+ groupId + ' exclude - '+this.palz.exclude_group_member_id);
            let seq = this.api.get('palz', this.palz).share();
            seq.subscribe((res: any) => {
              console.log('result with update api');  
              console.log(res.message); 
              if (res.status == 'success') {
                this.insertMembers(res.data, groupId);
              }
            }, err => {
              console.log('checkUpdateNewPalz: Error with update api ');
              console.error('ERROR', err);
            });
          }
        })
      }
    });
    
  }
  
  async insertMembers(data, group_id){    
    console.log('update insert_reached');
    for(let member of data){
      console.log('inserting ' + member.group_id +'...');
      await this.addPeople(member).then(data => {
        console.log('inserted ' + member.group_id);
      })
    }  
    this.insertMembersProgfileImage(group_id);
    this.showToast('Update: New Palz profile(s) added', 10000);
  }

  async insertAlbum(data){    
    console.log('update insert Album reached');
    for(let member of data){
      await this.addAlbum(member).then(data => {
        console.log('inserted ' + member.name);
      })
    } 
    this.showToast('Update: New Album(s) added', 10000);
  }

  async insertPhoto(data){  
    let groupId = this.groupId;  
    console.log('update insert Photo reached for group: '+groupId);
    for(let member of data){
      console.log('calling  addPhoto for ' + member.name);
      await this.addPhoto(member, groupId).then(data => {        
      })
    } 
    console.log('Update: New Photo(s) added, download pending.');
    this.showToast('Update: New Photo(s) added, download pending.', 7000);
  }

  async insertMembersProgfileImage(group_id){
      console.log('downloading images for ' + group_id +'...');
        this.downloadProfileImage(group_id).then(data => { 
          console.log('downloaded images for ' + group_id);    
    })
  }

  
  async checkUpdateNewAlbum(){
    console.log('checkUpdateNewAlbum');

    let groupId = this.groupId;

    if(!groupId){
      console.log('Aborting checkUpdateNewAlbum, REASON: No group id set');
      return;
    }
    console.log('Preparing for Album update for group '+ groupId);     
    this.getAlbumAll(groupId).then(data => {
      if(data.status = 'success'){
        console.log('success with update checkUpdateNewAlbum'); 
        this.album.exclude_album_id =  data.str_album_id;
        this.album.group_id =  groupId;
        console.log('Executing update for group '+ this.album.group_id + ' exclude - '+this.album.exclude_album_id);
        let seq = this.api.get('album', this.album).share();
        seq.subscribe((res: any) => {
          console.log('result with album update api');  
          console.log(res.message); 
          if (res.status == 'success') {
            this.insertAlbum(res.data);
            console.log('Album(s) inserted');  
          }
        }, err => {
          console.log('checkUpdateNewAlbum: Error with update api ');
          console.error('ERROR', err);
        });
      }
    })
    
  }

  async checkUpdateNewPhoto(){
    console.log('checkUpdateNewPhoto');

    let groupId = this.groupId;

    if(!groupId){
      console.log('Aborting checkUpdateNewPhoto, REASON: No group id set');
      return;
    }

    console.log('Preparing for Photo update for group '+ groupId);     
    await this.getPhotoAll(groupId).then(dataP => {
      if(dataP.status = 'success'){
        console.log('success with photo getPhotoAll'); 
        this.photo.exclude_photo_id =  dataP.str_photo_id;
        this.getGroupMemberIdAll(groupId).then(data => {
          if(data.status = 'success'){
            console.log('success with photo getGroupMemberIdAll'); 
            this.photo.group_member_id =  data.str_member_id;
            console.log('Executing photo update for members '+ this.photo.group_member_id + ' exclude - '+this.photo.exclude_photo_id);
            let seq = this.api.get('photo', this.photo).share();
            seq.subscribe((res: any) => {
              console.log('result with photo update api');  
              console.log(res.message); 
              if (res.status == 'success') {
                this.insertPhoto(res.data);
                console.log('Photo(s) inserted');  
              }
            }, err => {
              console.log('checkUpdateNewPhoto: Error with update api ');
              console.error('ERROR', err);
            });
            

          }
        })

      }
    })

    console.log('Exiting Photo update for group '+ groupId);  
    
  }

  async  checkUpdatedownloadImage(){
    console.log('checkUpdatedownloadImage');

    let groupId = this.groupId;

    if(!groupId){
      console.log('Aborting checkUpdatedownloadImage, REASON: No group id set');
      return;
    }
    console.log('Preparing for downloadImage update for group '+ groupId);
    this. downloadImage(groupId);
    console.log('Done for downloadImage update for group '+ groupId);
  }

  showToast(message:string, duration: number){
    let toast = this.toastCtrl.create({
      message: message,
      duration: duration,
      position: 'top'
    });
    toast.present();
  }


  async updatehandler(){

    let groupId = this.groupId;

    if(!groupId){
      console.log('Aborting updatehandler, REASON: No group id set');
      return;
    }

    this.checkUpdateNewAlbum();
    this.checkUpdateNewPhoto();
  
    setTimeout(() => {
      this.checkUpdatedownloadImage();
    }, 30000);

    setTimeout(() => {
      this.checkUpdateNewPalz();
    }, 60000);
    
  }



  resoveImagePath(name){
    return this.file.dataDirectory + name;
  }

}