import { Injectable } from '@angular/core';
import { DatabaseProvider } from './../../providers/database/database';
import { Member } from '../../models/member';

@Injectable()
export class MembersService {

  constructor(private databaseprovider: DatabaseProvider){
    
  }

  members:Member[];

  loadMembers(){
    this.databaseprovider.getDatabaseState().subscribe(rdy => {
      if (rdy) {
        this.loadMemberData();
      }
    })
  }

  async loadMemberData() {
    await this.databaseprovider.getAllMembers().then(data => {
      if(data){
        this.members = data;
      }
    })
  }

  getMembers(): Member[] {
      return this.members;
  } 

  highlight(contenText, keyText){
    if(!keyText){
      return contenText;
    }

    return contenText.replace(new RegExp(keyText, "gi"), match => {
      return '<span style = "background-color:#FFFF00;">' + match + '</span>';
    });
  }
};