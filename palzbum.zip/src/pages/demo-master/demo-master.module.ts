import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { DemoMasterPage } from './demo-master';

@NgModule({
  declarations: [
    DemoMasterPage,
  ],
  imports: [
    IonicPageModule.forChild(DemoMasterPage),
    TranslateModule.forChild()
  ],
  exports: [
    DemoMasterPage
  ]
})
export class DemoMasterPageModule { }
