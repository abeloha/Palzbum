import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Platform } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-image-view',
  templateUrl: 'image-view.html'
})
export class ImageViewPage {
  img: string;
 
  constructor(public platform: Platform, navParams: NavParams, public navCtrl: NavController) { 
    this.img = navParams.get('image') || '';
   }
}
