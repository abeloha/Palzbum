import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { ImageViewPage } from './image-view';

@NgModule({
  declarations: [
    ImageViewPage,
  ],
  imports: [
    IonicPageModule.forChild(ImageViewPage),
    TranslateModule.forChild()
  ],
  exports: [
    ImageViewPage
  ]
})
export class ImageViewPageModule { }
