import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { WebPage } from './web';

@NgModule({
  declarations: [
    WebPage,
  ],
  imports: [
    IonicPageModule.forChild(WebPage),
    TranslateModule.forChild()
  ],
  exports: [
    WebPage
  ]
})
export class WebPageModule { }
