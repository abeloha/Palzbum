import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IonicPage, NavController, ToastController, AlertController, LoadingController, NavParams } from 'ionic-angular';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { RootUrl } from '../';
@IonicPage()
@Component({
  selector: 'page-web',
  templateUrl: 'web.html'
})
export class WebPage {
  account: { name: string, email: string, password: string } = {
    name: 'Test Human',
    email: 'test@example.com',
    password: 'test'
  };

  options : InAppBrowserOptions = {
    location : 'no',//Or 'no' 
    hidden : 'yes', //Or  'yes' 
    //hideurlbar : 'yes', //Or  'yes' 
    zoom : 'no',//Android only ,shows browser zoom controls 
    hardwareback : 'yes',
    mediaPlaybackRequiresUserAction : 'no',
    shouldPauseOnSuspend : 'no', //Android only 
    closebuttoncaption : 'Close', //iOS only
    disallowoverscroll : 'no', //iOS only 
    toolbar : 'yes', //iOS only 
    enableViewportScale : 'no', //iOS only 
    allowInlineMediaPlayback : 'no',//iOS only 
    presentationstyle : 'pagesheet',//iOS only 
    fullscreen : 'yes',//Windows only    
};

  // Our translated text strings
  palzbumUrl = RootUrl;
  rootUrl;
  browerErrorOccured = 0;
  private loading;
  constructor(public navCtrl: NavController, navParams: NavParams,  private theInAppBrowser: InAppBrowser,
    public toastCtrl: ToastController, public alertController: AlertController,
    public loadingCtrl: LoadingController, public translateService: TranslateService) {

      this.rootUrl = navParams.get('url') || RootUrl;
      this.openWithInAppBrowser(this.rootUrl);     
  }

  public openWithInAppBrowser(url : string){
      let target = "_blank";      

      //let inAppBrowserRef = this.theInAppBrowser.create(url,target,this.options);
      //inAppBrowserRef.show();

      this.showLoading();
      let inAppBrowserRef = this.theInAppBrowser.create(url,target,this.options);

      inAppBrowserRef.on('loadstart').subscribe(event =>{
        console.log('Browser Test loadStartCallBack');
        this.browerErrorOccured = 0;
        this.showLoading();
      });

      inAppBrowserRef.on('loadstop').subscribe(event =>{
        
        console.log('Browser Test loadStopCallBack');
        this.hideLoading();
          if (inAppBrowserRef != undefined && this.browerErrorOccured == 0) {
            console.log('Browser Test loadStopCallBack true');
            inAppBrowserRef.insertCSS({ code: "body{font-size: 25px;" });
            this.hideLoading();
            inAppBrowserRef.show();
          }

      });

      inAppBrowserRef.on('loaderror').subscribe(event =>{
        console.log('Browser Test loadErrorCallBack for ' + event.url);
        this.rootUrl = event.url;
        this.hideLoading();
        this.presentAlert("Sorry we couldn't open that page. Check your network connectivity and try again.");
        this.browerErrorOccured = 1;
        inAppBrowserRef.hide();
        //inAppBrowserRef = undefined;
      });
  }
  
alreadyDismissed = false;

private showLoading(){
  this.alreadyDismissed = false;

  this.loading = this.loadingCtrl.create({
  content: 'Loading, please wait...'
  });
  this.loading.present().then(() =>{
      if(this.alreadyDismissed){
        this.loading.dismissAll();
      }
  });
}

private hideLoading(){  
  this.loading.dismissAll();
  this.alreadyDismissed = true;
}


async presentAlert(message) {
  const alert = await this.alertController.create({
    message: message,
    buttons: ['OK']
  });
  await alert.present();
}

ionViewDidLeave(){
  this.loading.dismissAll();
}

}
