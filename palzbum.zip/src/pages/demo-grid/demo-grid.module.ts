import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { DemoGridPage } from './demo-grid';

@NgModule({
  declarations: [
    DemoGridPage,
  ],
  imports: [
    IonicPageModule.forChild(DemoGridPage),
    TranslateModule.forChild()
  ],
  exports: [
    DemoGridPage
  ]
})
export class DemoGridPageModule { }
