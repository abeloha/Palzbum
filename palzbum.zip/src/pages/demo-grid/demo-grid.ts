import { DatabaseProvider } from './../../providers/database/database';
import { Component } from '@angular/core';
import { IonicPage, NavController, } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-demo-grid',
  templateUrl: 'demo-grid.html'
})
export class DemoGridPage {
  member = {};
  members = [];  
  membersMaster = []; 
  searchTerm: string = '';
 
  constructor(public navCtrl: NavController, private databaseprovider: DatabaseProvider) {
    this.databaseprovider.getDatabaseState().subscribe(rdy => {
      if (rdy) {
        this.loadMemberData();
      }
    })
  }
 
  openItem(group_member_id) {
    this.navCtrl.push('DemoDetailPage', {
      group_member_id: group_member_id
    },{
      animate: true,
      direction: 'forward'
    });
  }

  loadMemberData() {
    this.databaseprovider.getAllDemoMembers().then(data => {
      this.members = data;
      this.membersMaster = data;
    })
  }

  initializeMember(): void {
    this.members = this.membersMaster;
  }

  searchMembers(){

    // Reset Members array back to all of the items
    this.initializeMember();

    // if the search term is an empty string return all items
    if (!this.searchTerm) {
      return this.members;
    }
    
    // Filter members
    this.members = this.members.filter((item) => {
        return item.name.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1;
    }); 
    
  }

  openList()  {
    this.navCtrl.push('DemoMasterPage');
  }

}
